# Open Door — HR Work-Environment Feedback

Two pages:
- `public/index.html` — the form employees use to send feedback (optionally anonymous).
- `public/dashboard.html` — a code-gated dashboard where HR views, filters, and triages submissions.

Data lives in a Google Sheet, read and written through three small Netlify
Functions. No database to run, and the "database" is a spreadsheet you can
open, sort, or export to Excel any time.

---

## 1. Create the Google Sheet

1. Create a new Google Sheet. Name it whatever you like (e.g. **HR Feedback**).
2. Rename the first tab to exactly `Feedback` (case-sensitive — the code
   looks for this tab name).
3. Leave it otherwise empty — the app writes its own header row the first
   time it runs.
4. Copy the **Sheet ID** out of the URL:
   `https://docs.google.com/spreadsheets/d/`**`THIS_PART`**`/edit`

## 2. Create a Google service account

This lets the Netlify Functions read/write the sheet without a human login.

1. Go to [Google Cloud Console](https://console.cloud.google.com/) → create
   a project (or reuse one).
2. Enable the **Google Sheets API** for that project (APIs & Services →
   Enable APIs → search "Google Sheets API").
3. Go to **APIs & Services → Credentials → Create Credentials → Service
   Account**. Give it any name (e.g. `hr-feedback-bot`).
4. Open the new service account → **Keys** tab → **Add Key → Create new key
   → JSON**. This downloads a `.json` file — keep it private, don't commit
   it anywhere.
5. Copy the **client email** and **private key** out of that JSON file —
   you'll need them for environment variables below.
6. Back in your Google Sheet, click **Share**, and share it with the
   service account's email address (the long `...@...gserviceaccount.com`
   address) with **Editor** access.

## 3. Choose an HR access code

Pick a passphrase HR staff will type into the dashboard gate. This is a
simple shared-secret gate, not full user accounts — good enough for a small
internal tool. Store it as `HR_ACCESS_CODE` below.

## 4. Deploy to Netlify

1. Push this folder to a GitHub/GitLab repo, or drag-and-drop deploy it in
   the Netlify UI.
2. In Netlify: **Site settings → Environment variables**, add:

   | Key | Value |
   |---|---|
   | `GOOGLE_SERVICE_ACCOUNT_EMAIL` | the `client_email` from the JSON key |
   | `GOOGLE_PRIVATE_KEY` | the `private_key` from the JSON key, **keep the quotes and `\n` characters as-is** |
   | `SHEET_ID` | the Sheet ID from step 1 |
   | `HR_ACCESS_CODE` | the passphrase from step 3 |

3. Deploy. Netlify will publish `public/` as the site and `netlify/functions/`
   as serverless functions automatically (see `netlify.toml`).
4. Visit your site:
   - `/` — the employee feedback form
   - `/dashboard.html` — the HR dashboard (prompts for the access code)

## 5. Test it locally (optional)

```bash
npm install
npm install -g netlify-cli   # if you don't already have it
netlify dev
```

`netlify dev` reads the same environment variables from a `.env` file if
you create one locally (never commit it):

```
GOOGLE_SERVICE_ACCOUNT_EMAIL=...
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
SHEET_ID=...
HR_ACCESS_CODE=...
```

---

## How it works

- **Employee submits** → `POST /api/submit-feedback` → appends a row to the
  `Feedback` tab (ID, timestamp, name-or-"Anonymous", department, category,
  message, status = `New`, empty HR notes).
- **HR opens dashboard** → enters access code → `GET /api/get-feedback`
  (checked against `HR_ACCESS_CODE`) → returns all rows as JSON, newest
  first.
- **HR updates a submission** → `POST /api/update-status` → finds the row
  by ID and updates its `Status` and/or `HR Notes` columns.

## Notes on privacy

- When an employee chooses "anonymous," no name is stored at all — the
  row just says `Anonymous`. There's nothing to reverse.
- The Google Sheet itself is only as private as who you've shared it with —
  keep sharing limited to the service account and whoever in HR needs
  direct spreadsheet access.
- The dashboard access code is a basic shared-secret gate. If this grows
  beyond a small internal tool, swap `_auth.js` for real per-person
  authentication (e.g. Netlify Identity or your hospital's SSO).

## Customizing

- Categories are defined in two places and should be kept in sync:
  `netlify/functions/submit-feedback.js` (`ALLOWED_CATEGORIES`) and
  `public/index.html` / `public/dashboard.html` (the `<select>` options).
- Colors and type live as CSS variables at the top of each HTML file's
  `<style>` block.
